#ifndef HLS_MACC_H_
#define HLS_MACC_H_

#include <stdbool.h>

void hls_macc(int a, int b, int *accum, bool accum_clr);

#endif //#ifndef HLS_MACC_H_

