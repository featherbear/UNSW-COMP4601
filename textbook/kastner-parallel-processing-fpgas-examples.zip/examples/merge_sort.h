const static int SIZE = 16;
typedef float DTYPE;
extern void merge_sort(DTYPE A[SIZE]);
