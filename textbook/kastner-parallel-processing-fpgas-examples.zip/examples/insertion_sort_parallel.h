const static int SIZE = 16;
typedef int DTYPE;
extern void insertion_sort_parallel(DTYPE A[SIZE], DTYPE B[SIZE]);
