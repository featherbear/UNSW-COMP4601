#define INPUT_SIZE 8
#define VALUE_SIZE 256

extern void histogram(int in[INPUT_SIZE], int hist[VALUE_SIZE]);
