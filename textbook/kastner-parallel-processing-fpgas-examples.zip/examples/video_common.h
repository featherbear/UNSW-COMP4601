typedef struct rgb_pixel {
    unsigned char R;
    unsigned char G;
    unsigned char B;
} rgb_pixel;

//#define MAX_HEIGHT 1080
//#define MAX_WIDTH 1920
#define MAX_HEIGHT 20
#define MAX_WIDTH 20
