#include "hls_stream.h"
#include "insertion_sort.h"
void insertion_cell_sort(hls::stream<DTYPE> & in, hls::stream<DTYPE> & out);
